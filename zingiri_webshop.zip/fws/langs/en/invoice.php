<html>
	<head>
		<title>%webid%</title>
		<link rel="stylesheet" type="text/css" href="templates/%template%/stylesheet.css" />
	</head>
	
	<body>
		<div align="center">
			<img src="http://www.freewebshop.org/demo/templates/%template%/images/logo.gif" />
				<h1>Factuur</h1>
				<br />
				<table class="borderless" width="95%">
					<tr><td>%customer_details%</td></tr>
					<tr><td>%product_list%</td></tr>
				</table>
				<br />
		</div>		
	</body>
</html>	